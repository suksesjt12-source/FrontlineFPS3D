# DXVK package layout

Place the Windows 64-bit DLLs under `x64/` and preserve upstream release notices. Typical DLLs include `d3d9.dll`, `d3d10core.dll`, `d3d11.dll`, and `dxgi.dll`.

DXVK is a Vulkan-based implementation of Direct3D 8/9/10/11 for Wine. It is not a GPU driver and depends on a working Vulkan path.
