# WineD3D fallback

WineD3D translates Direct3D through OpenGL. It is an alternative path for some applications, not a universal fallback and not guaranteed to work with the Android host graphics stack. Integration and performance must be tested per device/game.
