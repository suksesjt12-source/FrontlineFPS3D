# Vulkan bridge contract

Expected guest-side location: `graphics/vulkan/x86_64/libvulkan.so.1`.

This must be an x86-64 guest library able to forward Vulkan calls to an ARM64 Android-host implementation. It must expose a compatible Vulkan loader interface and enumerate the host GPU correctly. The ARM64 Android driver itself is normally supplied by the device vendor; do not replace it with an Adreno-only driver on Mali hardware.

Status: **not implemented**. DXVK and VKD3D-Proton cannot be considered usable until this bridge is built and tested.
