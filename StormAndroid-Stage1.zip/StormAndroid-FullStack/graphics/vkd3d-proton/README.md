# VKD3D-Proton package layout

Place 64-bit Windows DLLs such as `d3d12.dll` and `d3d12core.dll` under `x64/`. VKD3D-Proton is for Direct3D 12 over Vulkan; it is optional for titles that do not use Direct3D 12 and still requires a working Vulkan bridge.
