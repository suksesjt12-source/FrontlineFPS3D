# Graphics stack

Storm's graphics path is planned as:

`Windows Direct3D app -> Wine D3D libraries -> DXVK or VKD3D-Proton -> guest Vulkan loader -> ARM64 Android Vulkan bridge -> device Vulkan driver`

Mali-specific bridge implementation is not present yet. The Android system driver must be queried and exercised on the actual device; copying an arbitrary Mesa driver into this folder is not a valid substitute.
