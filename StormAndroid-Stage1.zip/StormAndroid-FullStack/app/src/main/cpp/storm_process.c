#define _GNU_SOURCE
#include <jni.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef AT_EMPTY_PATH
#define AT_EMPTY_PATH 0x1000
#endif
#ifndef __NR_memfd_create
#define __NR_memfd_create 279
#endif
#ifndef __NR_execveat
#define __NR_execveat 281
#endif

static int copy_to_memfd(const char *path) {
    int input = open(path, O_RDONLY | O_CLOEXEC);
    if (input < 0) return -1;
    int output = (int)syscall(__NR_memfd_create, "storm-runtime", 0);
    if (output < 0) { close(input); return -1; }
    char buffer[65536];
    ssize_t count;
    while ((count = read(input, buffer, sizeof(buffer))) > 0) {
        ssize_t offset = 0;
        while (offset < count) {
            ssize_t written = write(output, buffer + offset, (size_t)(count - offset));
            if (written <= 0) { close(input); close(output); return -1; }
            offset += written;
        }
    }
    close(input);
    if (count < 0 || lseek(output, 0, SEEK_SET) < 0) { close(output); return -1; }
    return output;
}

static char **copy_java_array(JNIEnv *env, jobjectArray array, jsize *length) {
    *length = array ? (*env)->GetArrayLength(env, array) : 0;
    char **result = (char **)calloc((size_t)(*length) + 1, sizeof(char *));
    if (!result) return NULL;
    for (jsize i = 0; i < *length; i++) {
        jstring value = (jstring)(*env)->GetObjectArrayElement(env, array, i);
        const char *chars = (*env)->GetStringUTFChars(env, value, NULL);
        result[i] = strdup(chars ? chars : "");
        if (chars) (*env)->ReleaseStringUTFChars(env, value, chars);
        (*env)->DeleteLocalRef(env, value);
        if (!result[i]) return result;
    }
    return result;
}

static void free_array(char **array) {
    if (!array) return;
    for (size_t i = 0; array[i]; i++) free(array[i]);
    free(array);
}

JNIEXPORT jint JNICALL
Java_com_stormlauncher_android_NativeProcessBridge_start(
        JNIEnv *env, jclass clazz, jstring executable, jobjectArray arguments,
        jobjectArray environment, jstring workingDirectory, jstring logFile) {
    (void)clazz;
    const char *exe = (*env)->GetStringUTFChars(env, executable, NULL);
    const char *cwd = (*env)->GetStringUTFChars(env, workingDirectory, NULL);
    const char *log = (*env)->GetStringUTFChars(env, logFile, NULL);
    jsize argc = 0, envc = 0;
    char **args = copy_java_array(env, arguments, &argc);
    char **envp = copy_java_array(env, environment, &envc);
    (void)envc;
    if (!exe || !cwd || !log || !args || !envp) goto failure;

    char **argv = (char **)calloc((size_t)argc + 2, sizeof(char *));
    if (!argv) goto failure;
    argv[0] = strdup(exe);
    for (jsize i = 0; i < argc; i++) argv[i + 1] = strdup(args[i]);
    if (!argv[0]) { free_array(argv); goto failure; }

    int executable_fd = copy_to_memfd(exe);
    if (executable_fd < 0) { free_array(argv); goto failure; }
    int log_fd = open(log, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    if (log_fd < 0) { close(executable_fd); free_array(argv); goto failure; }

    pid_t pid = fork();
    if (pid == 0) {
        dup2(log_fd, STDOUT_FILENO);
        dup2(log_fd, STDERR_FILENO);
        close(log_fd);
        if (chdir(cwd) != 0) _exit(126);
        syscall(__NR_execveat, executable_fd, "", argv, envp, AT_EMPTY_PATH);
        dprintf(STDERR_FILENO, "Storm execveat failed: errno=%d (%s)\n", errno, strerror(errno));
        _exit(127);
    }
    int saved_errno = errno;
    close(log_fd); close(executable_fd);
    free_array(argv); free_array(args); free_array(envp);
    (*env)->ReleaseStringUTFChars(env, executable, exe);
    (*env)->ReleaseStringUTFChars(env, workingDirectory, cwd);
    (*env)->ReleaseStringUTFChars(env, logFile, log);
    return pid < 0 ? -saved_errno : (jint)pid;

failure:
    free_array(args); free_array(envp);
    if (exe) (*env)->ReleaseStringUTFChars(env, executable, exe);
    if (cwd) (*env)->ReleaseStringUTFChars(env, workingDirectory, cwd);
    if (log) (*env)->ReleaseStringUTFChars(env, logFile, log);
    return -errno;
}

JNIEXPORT jint JNICALL
Java_com_stormlauncher_android_NativeProcessBridge_waitFor(JNIEnv *env, jclass clazz, jint pid) {
    (void)env; (void)clazz;
    int status = 0;
    if (waitpid((pid_t)pid, &status, 0) < 0) return -errno;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return status;
}

JNIEXPORT jint JNICALL
Java_com_stormlauncher_android_NativeProcessBridge_terminate(JNIEnv *env, jclass clazz, jint pid) {
    (void)env; (void)clazz;
    return kill((pid_t)pid, SIGTERM) == 0 ? 0 : -errno;
}
