package com.stormlauncher.android;

/** Native process launcher. Copies an imported ARM64 ELF to memfd and calls execveat. */
public final class NativeProcessBridge {
    static { System.loadLibrary("stormprocess"); }
    private NativeProcessBridge() {}

    public static native int start(String executable, String[] arguments,
            String[] environment, String workingDirectory, String logFile);
    public static native int waitFor(int pid);
    public static native int terminate(int pid);
}
