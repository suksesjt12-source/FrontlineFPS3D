package com.stormlauncher.android;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

final class RuntimeEngine {
    private RuntimeEngine() {}

    static int launch(File runtime, File gameExe, File appFiles, File logFile) throws Exception {
        File proot = new File(runtime, "bin/proot");
        File rootfs = new File(runtime, "rootfs");
        File box64 = new File(rootfs, "usr/bin/box64");
        File wine = new File(rootfs, "usr/bin/wine");
        if (!wine.isFile()) wine = new File(rootfs, "usr/bin/wine64");
        require(proot, "bin/proot (Android ARM64)");
        require(rootfs, "rootfs");
        require(box64, "rootfs/usr/bin/box64");
        require(wine, "rootfs/usr/bin/wine or wine64");
        require(gameExe, "game EXE");

        File gameDir = gameExe.getParentFile();
        List<String> args = new ArrayList<>();
        args.add("-0");
        args.add("-r"); args.add(rootfs.getAbsolutePath());
        args.add("-w"); args.add("/mnt/game");
        args.add("-b"); args.add("/dev");
        args.add("-b"); args.add("/proc");
        args.add("-b"); args.add("/sys");
        args.add("-b"); args.add(gameDir.getAbsolutePath() + ":/mnt/game");
        args.add("/usr/bin/env");
        args.add("HOME=/root");
        args.add("TMPDIR=/tmp");
        args.add("PROOT_NO_SECCOMP=1");
        args.add("BOX64_DYNAREC=1");
        args.add("BOX64_LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu:/usr/lib/wine/x86_64-unix");
        args.add("/usr/bin/box64");
        args.add(wine.getAbsolutePath().substring(rootfs.getAbsolutePath().length()));
        args.add("/mnt/game/" + gameExe.getName());

        File home = new File(appFiles, "home");
        File temp = new File(appFiles, "tmp");
        home.mkdirs(); temp.mkdirs();
        String[] env = {
                "PATH=/system/bin:/system/xbin",
                "HOME=" + home.getAbsolutePath(),
                "TMPDIR=" + temp.getAbsolutePath()
        };
        return NativeProcessBridge.start(proot.getAbsolutePath(),
                args.toArray(new String[0]), env, appFiles.getAbsolutePath(), logFile.getAbsolutePath());
    }

    private static void require(File file, String label) throws Exception {
        if (!file.exists()) throw new Exception("Komponen runtime tidak ditemukan: " + label);
    }
}
