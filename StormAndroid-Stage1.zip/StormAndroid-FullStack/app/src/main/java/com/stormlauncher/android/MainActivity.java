package com.stormlauncher.android;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.documentfile.provider.DocumentFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int PICK_GAME_FOLDER = 10;
    private static final int PICK_RUNTIME_ZIP = 11;
    private static final int BG = Color.rgb(12, 17, 27);
    private static final int PANEL = Color.rgb(25, 34, 49);
    private static final int TEXT = Color.rgb(238, 242, 249);
    private static final int MUTED = Color.rgb(153, 168, 190);
    private static final int ACCENT = Color.rgb(86, 156, 255);

    private LinearLayout content;
    private TextView status;
    private String statusMessage = "Status: launcher siap.";
    private File gamesDir;
    private File runtimeDir;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        gamesDir = new File(getFilesDir(), "games");
        runtimeDir = new File(getFilesDir(), "runtime");
        gamesDir.mkdirs();
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(26), dp(20), dp(30));
        scroll.addView(content);
        setContentView(scroll);

        TextView logo = text("STORM", 30, TEXT, true);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        content.addView(logo);
        content.addView(text("ANDROID WINDOWS GAME LAUNCHER", 11, MUTED, true));
        addSpace(20);

        addButton("IMPORT GAME FOLDER", v -> pickGameFolder());
        addButton("IMPORT RUNTIME PACKAGE (.ZIP)", v -> pickRuntimeZip());
        status = text(statusMessage, 13, MUTED, false);
        status.setPadding(dp(2), dp(12), dp(2), dp(12));
        content.addView(status);

        addSection("RUNTIME STATUS");
        content.addView(text(RuntimeInspector.isCoreReady(runtimeDir)
                ? "Core files detected. Display/Vulkan integration is still required before games can run."
                : "Core runtime incomplete. Import a compatible runtime ZIP after its components have been built.", 13, MUTED, false));
        addSection("RUNTIME COMPONENT CHECK");
        for (RuntimeInspector.Item item : RuntimeInspector.inspect(runtimeDir)) {
            String label = item.group + "  /  " + item.name + "  —  " + item.status();
            int color = item.present ? Color.rgb(91, 190, 133)
                    : (item.required ? Color.rgb(245, 157, 85) : MUTED);
            content.addView(text(label, 12, color, false));
        }
        addSpace(8);
        content.addView(text("A file marked FOUND is only a presence check, not a compatibility or performance test.", 11, MUTED, false));
        addSection("GAME LIBRARY");
        renderGames();
        addSpace(18);
        content.addView(text("Storm has its own UI and native process launcher. Wine, Box64, PRoot, the Linux rootfs and graphics runtime are separate components; they are not fabricated by the APK build.", 11, MUTED, false));
    }

    private void renderGames() {
        File[] folders = gamesDir.listFiles(File::isDirectory);
        if (folders == null || folders.length == 0) {
            content.addView(text("No games imported. Import the complete game installation folder, not only the EXE, so its data files remain available.", 13, MUTED, false));
            return;
        }
        for (File folder : folders) {
            List<File> exes = new ArrayList<>();
            collectExecutables(folder, exes, 0);
            LinearLayout card = card();
            card.addView(text(folder.getName(), 16, TEXT, true));
            if (exes.isEmpty()) {
                card.addView(text("No .exe file found in this folder.", 12, MUTED, false));
            } else {
                for (File exe : exes) {
                    Button play = smallButton("PLAY  •  " + relativeName(folder, exe));
                    play.setOnClickListener(v -> launch(exe));
                    card.addView(play);
                }
            }
            content.addView(card);
            addSpace(10);
        }
    }

    private void launch(File exe) {
        if (!RuntimeInspector.isGameLaunchSupported(runtimeDir)) {
            setStatus("Game launch is disabled in this build: Android display bridge and Mali Vulkan guest bridge are not implemented/device-tested yet.");
            return;
        }
        File log = new File(getFilesDir(), "storm-last-run.log");
        try {
            int pid = RuntimeEngine.launch(runtimeDir, exe, getFilesDir(), log);
            if (pid <= 0) { setStatus("Process start failed. Native error: " + pid); return; }
            setStatus("Runtime process started. PID " + pid + ". Log: " + log.getAbsolutePath());
            new Thread(() -> {
                int exit = NativeProcessBridge.waitFor(pid);
                runOnUiThread(() -> setStatus("Process exited with code " + exit + ". Log: " + log.getAbsolutePath()));
            }, "storm-process-monitor").start();
        } catch (Throwable e) {
            setStatus("Launch failed: " + e.getClass().getSimpleName() + " — " + e.getMessage());
        }
    }

    private boolean runtimeReady() {
        return RuntimeInspector.isCoreReady(runtimeDir);
    }

    private void pickGameFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_GAME_FOLDER);
    }

    private void pickRuntimeZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_RUNTIME_ZIP);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_GAME_FOLDER) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                DocumentFile tree = DocumentFile.fromTreeUri(this, uri);
                if (tree == null || !tree.isDirectory()) throw new IOException("Folder cannot be opened.");
                String name = safeName(tree.getName() == null ? "Game" : tree.getName());
                File destination = new File(gamesDir, name);
                deleteRecursively(destination);
                destination.mkdirs();
                copyDocumentTree(tree, destination);
                setStatus("Game folder imported: " + name);
                buildUi();
            } catch (Exception e) { setStatus("Game import failed: " + e.getMessage()); }
        } else if (requestCode == PICK_RUNTIME_ZIP) {
            setStatus("Importing runtime ZIP. Keep Storm open while files are extracted.");
            new Thread(() -> {
                try {
                    installRuntimeZip(uri);
                    runOnUiThread(() -> {
                        setStatus(runtimeReady() ? "Runtime structure detected." : "ZIP extracted, but required files are missing. Check runtime/README.md.");
                        buildUi();
                    });
                } catch (Exception e) { runOnUiThread(() -> setStatus("Runtime import failed: " + e.getMessage())); }
            }, "storm-runtime-import").start();
        }
    }

    private void installRuntimeZip(Uri uri) throws Exception {
        File staging = new File(getFilesDir(), "runtime-new");
        deleteRecursively(staging);
        staging.mkdirs();
        String base = staging.getCanonicalPath() + File.separator;
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IOException("Cannot read selected ZIP.");
            try (ZipInputStream zip = new ZipInputStream(new java.io.BufferedInputStream(raw))) {
                ZipEntry entry;
                byte[] buffer = new byte[65536];
                while ((entry = zip.getNextEntry()) != null) {
                    File outFile = new File(staging, entry.getName());
                    String canonical = outFile.getCanonicalPath();
                    if (!canonical.startsWith(base) && !canonical.equals(staging.getCanonicalPath())) throw new IOException("Unsafe ZIP path rejected.");
                    if (entry.isDirectory()) outFile.mkdirs();
                    else {
                        File parent = outFile.getParentFile();
                        if (parent != null) parent.mkdirs();
                        try (FileOutputStream out = new FileOutputStream(outFile)) {
                            int n;
                            while ((n = zip.read(buffer)) != -1) out.write(buffer, 0, n);
                        }
                    }
                    zip.closeEntry();
                }
            }
        }
        File old = new File(getFilesDir(), "runtime-old");
        deleteRecursively(old);
        if (runtimeDir.exists() && !runtimeDir.renameTo(old)) throw new IOException("Cannot replace previous runtime.");
        if (!staging.renameTo(runtimeDir)) {
            if (old.exists()) old.renameTo(runtimeDir);
            throw new IOException("Cannot install new runtime.");
        }
        deleteRecursively(old);
        setExecutableTree(new File(runtimeDir, "bin"));
        setExecutableTree(new File(runtimeDir, "rootfs/usr/bin"));
    }

    private void setExecutableTree(File dir) {
        File[] items = dir.listFiles();
        if (items == null) return;
        for (File item : items) {
            if (item.isDirectory()) setExecutableTree(item);
            else { item.setReadable(true, false); item.setExecutable(true, false); }
        }
    }

    private void copyDocumentTree(DocumentFile source, File target) throws IOException {
        if (source.isDirectory()) {
            target.mkdirs();
            for (DocumentFile child : source.listFiles()) {
                String childName = safeName(child.getName() == null ? "item" : child.getName());
                copyDocumentTree(child, new File(target, childName));
            }
        } else {
            File parent = target.getParentFile();
            if (parent != null) parent.mkdirs();
            try (InputStream in = getContentResolver().openInputStream(source.getUri()); FileOutputStream out = new FileOutputStream(target)) {
                if (in == null) throw new IOException("Cannot read " + source.getName());
                byte[] buffer = new byte[65536];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
        }
    }

    private void collectExecutables(File folder, List<File> out, int depth) {
        if (depth > 14 || out.size() >= 40) return;
        File[] children = folder.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) collectExecutables(child, out, depth + 1);
            else if (child.getName().toLowerCase(Locale.ROOT).endsWith(".exe")) out.add(child);
        }
    }

    private String relativeName(File root, File file) {
        String prefix = root.getAbsolutePath() + File.separator;
        return file.getAbsolutePath().startsWith(prefix) ? file.getAbsolutePath().substring(prefix.length()) : file.getName();
    }

    private String safeName(String name) {
        String value = name.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        return value.isEmpty() ? "Imported" : value;
    }

    private void deleteRecursively(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        file.delete();
    }

    private void setStatus(String value) { statusMessage = value; if (status != null) status.setText(value); }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackgroundColor(PANEL);
        return box;
    }

    private void addButton(String label, View.OnClickListener listener) {
        Button b = smallButton(label);
        b.setOnClickListener(listener);
        content.addView(b);
        addSpace(8);
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return b;
    }

    private void addSection(String label) {
        addSpace(18);
        content.addView(text(label, 12, ACCENT, true));
        addSpace(8);
    }

    private void addSpace(int height) {
        View spacer = new View(this);
        content.addView(spacer, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
