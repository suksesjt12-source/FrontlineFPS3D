package com.stormlauncher.android;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Reports which pieces of the Windows-on-Android stack are actually present. */
final class RuntimeInspector {
    static final class Item {
        final String group;
        final String name;
        final String path;
        final boolean required;
        final boolean present;
        Item(String group, String name, String path, boolean required, boolean present) {
            this.group = group; this.name = name; this.path = path;
            this.required = required; this.present = present;
        }
        String status() { return present ? "FOUND" : (required ? "MISSING" : "OPTIONAL"); }
    }

    private RuntimeInspector() {}

    static List<Item> inspect(File runtime) {
        List<Item> items = new ArrayList<>();
        add(items, runtime, "Execution", "PRoot (Android ARM64)", "bin/proot", true);
        addAny(items, runtime, "Linux rootfs", "ARM64 glibc loader",
                new String[]{"rootfs/lib/ld-linux-aarch64.so.1", "rootfs/lib/aarch64-linux-gnu/ld-linux-aarch64.so.1"}, true);
        add(items, runtime, "Translation", "Box64 (ARM64)", "rootfs/usr/bin/box64", true);
        addAny(items, runtime, "Windows API", "Wine x86-64 entry point",
                new String[]{"rootfs/usr/bin/wine", "rootfs/usr/bin/wine64"}, true);
        addAny(items, runtime, "Linux rootfs", "x86-64 glibc loader",
                new String[]{"rootfs/lib64/ld-linux-x86-64.so.2", "rootfs/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2"}, true);
        add(items, runtime, "32-bit compatibility", "Box86 (optional)", "rootfs/usr/bin/box86", false);
        add(items, runtime, "Graphics", "DXVK D3D11", "graphics/dxvk/x64/d3d11.dll", false);
        add(items, runtime, "Graphics", "DXVK DXGI", "graphics/dxvk/x64/dxgi.dll", false);
        add(items, runtime, "Graphics", "VKD3D-Proton D3D12", "graphics/vkd3d-proton/x64/d3d12.dll", false);
        add(items, runtime, "Graphics", "Guest Vulkan loader/bridge", "graphics/vulkan/x86_64/libvulkan.so.1", true);
        add(items, runtime, "Display", "Android display/session bridge", "display/storm-display", true);
        add(items, runtime, "Audio", "PulseAudio server", "audio/bin/pulseaudio", false);
        add(items, runtime, "Audio", "ALSA configuration", "audio/alsa/alsa.conf", false);
        add(items, runtime, "Input", "XInput DLL", "input/xinput/xinput1_3.dll", false);
        add(items, runtime, "System", "Runtime manifest", "config/storm-runtime.json", true);
        return Collections.unmodifiableList(items);
    }

    static boolean isCoreReady(File runtime) {
        boolean proot = new File(runtime, "bin/proot").isFile();
        boolean box64 = new File(runtime, "rootfs/usr/bin/box64").isFile();
        boolean wine = new File(runtime, "rootfs/usr/bin/wine").isFile()
                || new File(runtime, "rootfs/usr/bin/wine64").isFile();
        boolean armLoader = existsAny(runtime, "rootfs/lib/ld-linux-aarch64.so.1",
                "rootfs/lib/aarch64-linux-gnu/ld-linux-aarch64.so.1");
        boolean x64Loader = existsAny(runtime, "rootfs/lib64/ld-linux-x86-64.so.2",
                "rootfs/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2");
        return proot && box64 && wine && armLoader && x64Loader;
    }

    /** This prototype deliberately keeps game launching disabled until the display/Vulkan
     * bridge has been implemented and device-tested. Presence of files alone is not proof. */
    static boolean isGameLaunchSupported(File runtime) {
        return false;
    }

    private static boolean existsAny(File root, String... paths) {
        for (String path : paths) if (new File(root, path).isFile()) return true;
        return false;
    }
    private static void add(List<Item> list, File root, String group, String name, String path, boolean required) {
        list.add(new Item(group, name, path, required, new File(root, path).isFile()));
    }
    private static void addAny(List<Item> list, File root, String group, String name, String[] paths, boolean required) {
        boolean present = existsAny(root, paths);
        list.add(new Item(group, name, paths[0], required, present));
    }
}
