# Input backend

Planned support: Android touchscreen overlay, gamepad input, SDL input translation, and Wine XInput DLLs. The touchscreen overlay should send controller events through the app/backend bridge; it should not depend on privileged access to raw `/dev/input` devices.
