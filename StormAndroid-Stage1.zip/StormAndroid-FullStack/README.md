# Storm Android — proyek launcher Windows game mandiri

Storm adalah proyek launcher Android terpisah. Proyek ini tidak mengunduh, menyalin, atau mengganti nama aplikasi Winlator. Arsitektur runtime yang dituju adalah PRoot + Linux rootfs ARM64 + Box64 + Wine x86-64 + backend grafis/audio/input/display.

## Yang sudah dibuat dalam ZIP ini

- Source aplikasi Android dengan UI Storm dan pustaka game.
- Impor seluruh folder instalasi game melalui Android Storage Access Framework.
- Impor paket runtime ZIP dengan pemeriksaan path untuk mencegah ZIP menulis ke luar folder runtime.
- Pemeriksa komponen PRoot, Box64, Wine, glibc loader, DXVK, VKD3D-Proton, Vulkan bridge, display, audio, dan input.
- JNI process-supervision prototype.
- GitHub Actions untuk membangun APK launcher.
- Kontrak struktur runtime, profil awal Helio G100/Mali-G57, dan skrip validasi paket.

## Yang belum tersedia — baca sebelum build

ZIP ini belum berisi binary PRoot, Box64, Wine, rootfs Linux, DLL DXVK/VKD3D, atau Mali Vulkan bridge. Backend Android Surface/display, audio, dan input juga belum selesai. Jadi ini **belum emulator Windows yang bisa menjalankan game**. Tombol menjalankan game sengaja diblokir sampai backend display dan Vulkan benar-benar tersedia serta diuji pada perangkat.

GitHub Actions saat ini hanya membangun APK launcher. Workflow tersebut tidak otomatis menghasilkan binary runtime Windows.

## Cara build APK lewat GitHub menggunakan HP

1. Ekstrak ZIP ini di HP.
2. Buka repository GitHub tujuan, lalu unggah **isi folder `StormAndroid-FullStack`** ke root repository. Pastikan folder tersembunyi `.github` ikut terunggah.
3. Buka tab **Actions**.
4. Pilih workflow **Build Storm Android APK**, lalu tekan **Run workflow**. Workflow juga berjalan saat ada push ke branch `main` atau `master`.
5. Setelah workflow berhasil, buka hasil run dan unduh artifact **Storm-Android-APK-prototype**. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

## Struktur paket runtime

Lihat `runtime/README.md`. ZIP runtime sungguhan harus memiliki folder `bin/`, `rootfs/`, `graphics/`, `display/`, `audio/`, `input/`, dan `config/` langsung di root arsip. Jalankan `scripts/validate-runtime-package.sh` sebelum mengimpor paket tersebut ke aplikasi.

## Profil perangkat

`runtime/profiles/helio-g100-mali-g57.json` menyediakan konfigurasi awal konservatif untuk perangkat kelas Infinix Hot 50 4G (Helio G100, Mali-G57 MC2, RAM 8 GB). Ini bukan hasil benchmark dan bukan klaim bahwa runtime sudah berfungsi pada perangkat tersebut.

## Lisensi dan asal binary

Gunakan hanya file game yang dimiliki secara sah. Setiap binary runtime pihak ketiga harus memiliki asal source/tag, lisensi, checksum SHA-256, dan catatan build. Isi `third_party/manifest.example.json` sebelum mendistribusikan build.


## New: build the Box64 ARM64 component

Open GitHub Actions and run **Build Storm runtime component - Box64 ARM64**. If successful, download the artifact `Storm-Box64-Linux-ARM64-component`. This artifact contains Box64 for Linux ARM64/glibc only; it is not the full runtime and cannot launch a Windows game by itself. See `runtime/build/README.md` and `docs/ROADMAP.md`.
