# Graphics backend

Responsible for host Vulkan capability discovery, guest Vulkan bridge lifecycle, DXVK/VKD3D DLL deployment, swapchain/surface handling, frame pacing, and device-loss reporting. Current status: design only.
