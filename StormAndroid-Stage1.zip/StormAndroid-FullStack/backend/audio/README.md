# Audio backend

Responsible for starting/stopping the Android-side audio service and routing guest audio streams. Current status: design only.
