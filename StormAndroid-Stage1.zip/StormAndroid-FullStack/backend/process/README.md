# Process backend

Current prototype uses JNI to start and supervise a native ARM64 process and capture stdout/stderr. This is not yet a validated PRoot/Box64/Wine launch chain. Android executable-storage restrictions and SELinux policy must be tested on target devices; a successful `fork`/`exec` result is not proof that Wine or a game can run.
