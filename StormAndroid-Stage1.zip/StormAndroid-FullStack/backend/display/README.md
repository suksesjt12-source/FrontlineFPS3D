# Display backend

Required interface: create an Android Surface, provide a guest display target, resize on orientation/viewport changes, forward lifecycle events, and present frames without copying more than necessary. This module is not implemented; game launching remains disabled.
