# Input backend

Responsible for mapping touchscreen and supported gamepads to guest keyboard/mouse/XInput events. Current status: design only.
