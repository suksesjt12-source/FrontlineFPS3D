# Storm Android architecture

```text
Storm Android APK
  ├─ Launcher / game library / SAF import
  ├─ Runtime manager + component verifier
  ├─ JNI process supervisor
  └─ Android services
      ├─ Display / Surface bridge       [not implemented]
      ├─ Vulkan host bridge (Mali)       [not implemented]
      ├─ Audio bridge                   [not implemented]
      └─ Input bridge                   [not implemented]

Runtime ZIP
  ├─ Android ARM64 PRoot
  └─ ARM64 Linux rootfs
      ├─ Box64 (ARM64 Linux)
      ├─ x86-64 Wine + x86-64 glibc dependencies
      ├─ Windows DLLs (DXVK / VKD3D)
      └─ guest Vulkan loader/bridge
```

## Process and architecture distinction

Box64 executes Linux x86-64 ELF programs on an ARM64 Linux userspace. Wine supplies Windows APIs and runs Windows PE programs. PRoot supplies a userspace filesystem/process environment. DXVK/VKD3D translate graphics APIs but are not drivers. The display bridge, Vulkan bridge, audio bridge, and input bridge connect the guest stack to Android.

The project is an independent launcher and integration codebase. It does not download, clone, rename, or repackage the Winlator application. It does use upstream third-party runtime components, which must be separately built and attributed.

## What is implemented in this source archive

- Android Java launcher and game-folder import.
- Runtime ZIP import with canonical-path validation.
- Runtime component inventory and missing-component reporting.
- JNI process-supervision prototype.
- GitHub Actions workflow to compile the Android APK.
- Runtime package contract and validation script.

## What is not implemented or verified

- Actual PRoot, Box64, Wine, or rootfs binaries.
- Multiarch glibc rootfs assembly.
- Android Mali Vulkan guest/host bridge.
- Android Surface/display backend.
- Guest audio service and XInput/touch mapping.
- A tested end-to-end Windows application launch.

The app intentionally refuses to launch games until the display/Vulkan path is implemented and device-tested.
