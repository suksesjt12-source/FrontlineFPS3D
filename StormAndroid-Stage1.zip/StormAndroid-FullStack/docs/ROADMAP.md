# Storm Android engineering roadmap

## Current source milestone

- Independent Android launcher source (not a Winlator APK fork/rebrand).
- Game-folder import through Android Storage Access Framework.
- Runtime ZIP import with path traversal checks.
- Runtime component inventory.
- JNI process-supervisor prototype.
- GitHub Actions workflow for the launcher APK.
- New GitHub Actions workflow to build the upstream Box64 Linux ARM64 component.

## Milestones still required before Windows game launch

1. Build/package Android ARM64 PRoot and its loader; validate execution on Android 14 without root.
2. Produce a compatible ARM64 glibc rootfs and validate Box64 inside it.
3. Integrate x86-64 Wine (including its complete dependency closure) and initialize a Wine prefix.
4. Implement a real Android Surface/display/session backend.
5. Implement and device-test the x86-64 Vulkan guest bridge against the Helio G100 Mali-G57 driver. DXVK must not be marked ready until Vulkan device extensions and presentation work.
6. Integrate audio and input/XInput mapping.
7. Run a small Windows test application, collect logs, then test the target game.

## Acceptance gates

- `box64 --version` runs inside the packaged ARM64 glibc rootfs on the phone.
- `wine --version` runs through Box64.
- A basic Windows GUI test appears on the Android display surface.
- Vulkan device enumeration and DXVK test pass on the actual Mali-G57 device.
- Only after those gates pass should the game launch control be enabled.

A successful Gradle build proves only that the Android launcher APK compiles. It does not prove the Windows runtime works.
