# Storm runtime package contract

Storm expects a ZIP whose root contains the directory layout below. Do not put the `runtime/` parent folder itself inside the ZIP.

```text
storm-runtime.zip
├── bin/
│   └── proot                         # Android ARM64 executable
├── rootfs/
│   ├── lib/                           # ARM64 glibc loader and libraries
│   ├── lib64/                         # x86-64 glibc loader (layout may vary)
│   └── usr/bin/
│       ├── box64                      # ARM64 Linux executable
│       ├── box86                      # optional 32-bit path
│       └── wine                       # x86-64 Wine entry point
├── graphics/
│   ├── vulkan/x86_64/libvulkan.so.1   # guest Vulkan loader/host bridge
│   ├── dxvk/x64/                      # d3d9/d3d10core/d3d11/dxgi DLLs
│   ├── vkd3d-proton/x64/              # d3d12/d3d12core DLLs
│   └── wined3d/                       # optional OpenGL fallback
├── display/
│   └── storm-display                 # Android Surface/display bridge (not yet implemented)
├── audio/
│   ├── bin/pulseaudio                 # optional native ARM64 server
│   └── alsa/                          # optional ALSA config/plugins
├── input/
│   └── xinput/                        # optional XInput DLLs
└── config/
    └── storm-runtime.json             # runtime manifest
```

## Architecture requirements

- Android host: ARM64 / `arm64-v8a`.
- PRoot: Android-compatible ARM64 executable. It is not interchangeable with a normal desktop Linux binary.
- Rootfs: ARM64 Linux userspace with the ARM64 dynamic loader and libraries needed by PRoot/Box64, plus the x86-64 loader and x86-64 libraries needed by Wine.
- Box64: ARM64 Linux binary compatible with the ARM64 rootfs. It runs Linux x86-64 ELF programs; it is not itself the Windows API layer.
- Wine: x86-64 Linux build, with its full runtime dependencies and a working Wine prefix.
- DXVK/VKD3D: Windows DLLs loaded by Wine. DXVK maps Direct3D 8/9/10/11 to Vulkan; VKD3D-Proton is the Direct3D 12 path. The guest Vulkan loader must reach a working Android-host Vulkan implementation through a compatible bridge.
- Display: an Android Surface/display bridge or a supported display server is necessary. Merely having Wine and DXVK does not make a visible game window appear.
- Audio/input: guest libraries and the corresponding Android-side services or bridges are required.

## Current implementation status

The APK has its own launcher UI, game-folder import, runtime ZIP import with path-traversal checks, component presence reporting, and a native process-supervision prototype. It does **not** yet include actual Wine/Box64/PRoot binaries or a rootfs. The Mali Vulkan bridge, Android display/Surface backend, audio bridge, and full input mapping are not implemented or device-tested. The app therefore deliberately blocks game launch instead of pretending that a partially assembled runtime is ready.

`storm-runtime.example.json` is a contract example, not proof that the files exist. Run `scripts/validate-runtime-package.sh /path/to/storm-runtime.zip` against a real package before importing it.
