# Runtime components and upstream projects

The following are the major upstream projects to integrate. Storm's Android application code is separate; it does not clone or rename another launcher.

| Component | Role | Upstream source |
|---|---|---|
| Box64 | ARM64-to-x86-64 Linux execution bridge | https://github.com/ptitSeb/box64 |
| Box86 (optional) | ARM32-to-x86 Linux compatibility path | https://github.com/ptitSeb/box86 |
| Wine | Windows API implementation | https://gitlab.winehq.org/wine/wine |
| PRoot | Userspace root filesystem/process environment | https://github.com/proot-me/proot |
| DXVK | Direct3D 8/9/10/11 over Vulkan | https://github.com/doitsujin/dxvk |
| VKD3D-Proton | Direct3D 12 over Vulkan | https://github.com/HansKristian-Work/vkd3d-proton |
| Mesa | Open-source graphics drivers and Vulkan infrastructure | https://gitlab.freedesktop.org/mesa/mesa |
| SDL | Cross-platform input/window/audio support library | https://github.com/libsdl-org/SDL |
| PulseAudio | Audio server option | https://gitlab.freedesktop.org/pulseaudio/pulseaudio |

## Critical Mali note

The target device uses a Mali GPU. Do not package Qualcomm Turnip as if it were a Mali driver: Turnip is an Adreno driver. Storm needs a tested route from the x86-64 Wine/Vulkan guest to the Android system Vulkan implementation for the Mali GPU. That bridge is currently a blocker and is intentionally not faked in this source package.

## Licensing and provenance

Each component has its own license and redistribution conditions. Before shipping any binary, record the exact upstream commit/tag, build flags, patches, binary SHA-256, and license text in `third_party/`. Do not bundle third-party components without preserving their notices and meeting their redistribution terms.
