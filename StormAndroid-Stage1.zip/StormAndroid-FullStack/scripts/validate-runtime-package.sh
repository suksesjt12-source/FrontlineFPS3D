#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/storm-runtime.zip" >&2
  exit 2
fi
ZIP="$1"
[[ -f "$ZIP" ]] || { echo "File not found: $ZIP" >&2; exit 2; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$ZIP" -d "$TMP"
ROOT="$TMP"

check_file() {
  local rel="$1"
  if [[ ! -f "$ROOT/$rel" ]]; then
    echo "MISSING: $rel"
    return 1
  fi
  echo "FOUND:   $rel"
}
check_any() {
  local label="$1"; shift
  for rel in "$@"; do
    if [[ -f "$ROOT/$rel" ]]; then echo "FOUND:   $label ($rel)"; return 0; fi
  done
  echo "MISSING: $label (checked: $*)"
  return 1
}

fail=0
check_file bin/proot || fail=1
check_file rootfs/usr/bin/box64 || fail=1
if [[ -f "$ROOT/rootfs/usr/bin/wine" ]]; then
  echo "FOUND:   rootfs/usr/bin/wine"
elif [[ -f "$ROOT/rootfs/usr/bin/wine64" ]]; then
  echo "FOUND:   rootfs/usr/bin/wine64"
else
  echo "MISSING: Wine entry point"; fail=1
fi
check_any "ARM64 glibc loader" rootfs/lib/ld-linux-aarch64.so.1 rootfs/lib/aarch64-linux-gnu/ld-linux-aarch64.so.1 || fail=1
check_any "x86-64 glibc loader" rootfs/lib64/ld-linux-x86-64.so.2 rootfs/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2 || fail=1
check_file graphics/vulkan/x86_64/libvulkan.so.1 || fail=1
check_file display/storm-display || fail=1
check_file config/storm-runtime.json || fail=1

if [[ -f "$ROOT/config/storm-runtime.json" ]]; then
  python3 -m json.tool "$ROOT/config/storm-runtime.json" >/dev/null || fail=1
fi

if [[ "$fail" -ne 0 ]]; then
  echo
  echo "Runtime package is incomplete. Even a complete file list still requires architecture checks and real-device testing." >&2
  exit 1
fi

echo
echo "File-layout checks passed. This does not certify ABI compatibility or game support."
