# Storm Android build status

| Area | Status |
|---|---|
| Independent Android launcher source | Implemented in source; APK build workflow provided |
| Game-folder import | Implemented |
| Runtime ZIP import with path validation | Implemented |
| Runtime inventory | Implemented |
| JNI process supervisor | Prototype; requires Android-device validation |
| Box64 Linux ARM64 build workflow | Added; runs separately in GitHub Actions |
| Android ARM64 PRoot + loader | Not yet packaged/device-tested |
| ARM64 glibc rootfs | Not yet packaged |
| x86-64 Wine + complete dependencies | Not yet packaged |
| Wine prefix/bootstrap | Not implemented |
| DXVK/VKD3D runtime packaging | Not yet integrated |
| Mali-G57 x86-64 Vulkan guest bridge | Not implemented/device-tested |
| Android display, audio and input backends | Not implemented/device-tested |
| End-to-end Windows game launch | Not yet supported |

The APK build workflow builds the Storm launcher. The Box64 workflow builds a separate Linux ARM64/glibc component. Neither workflow creates a complete Windows-on-Android emulator.
