# Audio backend

Planned options: PulseAudio client/server integration or ALSA compatibility libraries. A guest x86-64 client alone is insufficient; the Android-side audio output bridge must also exist. No server binary is included in this source package.
